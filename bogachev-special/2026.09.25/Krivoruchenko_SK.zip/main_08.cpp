#include <cmath>
#include <cstdio>
#include <ctime>

#include "init_f.h"
#include "solve_08.h"

/* ./a.out x_0 eps k.  */
int
main (int argc, char *argv[])
{
  double t, x_0, eps, x = 0;
  int k, cl, it, task = 8;
  int m = 5000;

  double (*f) (double);
  double (*f_lst[]) (double) = { f0, f1, f2, f3, f4, f5, f6 };
  int len_f = sizeof (f_lst) / sizeof (f_lst[0]);

  if (!((argc == 4) && sscanf (argv[1], "%lf", &x_0) == 1
        && (sscanf (argv[2], "%lf", &eps) == 1 && (eps >= 0))
        && ((sscanf (argv[3], "%d", &k) == 1) && ((0 <= k) && (k < len_f)))))
    {
      fprintf (stderr, "Usage: %s x_0 eps k\n", argv[0]);
      return -1;
    }

  f = f_lst[k];

  t = clock ();
  it = t8_solve (f, x_0, eps, m, &x);
  t = (clock () - t) / CLOCKS_PER_SEC;

  cl = get_call_count ();

  if (it < 0)
    {
      fprintf (stderr, "%s : Task = %d NOT FOUND Count = %d T = %.2f\n",
               argv[0], task, cl, t);
      return -2;
    }
  else
    {
      fprintf (stdout,
               "%s : Task = %d X = %e Res = %e Its = %d Count = %d T = %.2f\n",
               argv[0], task, x, f (x), it, cl, t);
      return 0;
    }
}
